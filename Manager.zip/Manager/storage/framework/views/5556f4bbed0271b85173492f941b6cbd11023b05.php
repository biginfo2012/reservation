<table class="table table-separate table-head-custom table-checkable" id="table">
    <thead>
    <tr>
        <th class="text-center"><?php echo e(__('shop')); ?>ID</th>
        <th class="text-center"><?php echo e(__('shop-name')); ?></th>
        <th class="text-center"><?php echo e(__('address')); ?></th>
        <th class="text-center"><?php echo e(__('phone')); ?></th>
        <th class="text-center"><?php echo e(__('email')); ?></th>
        <th class="text-center"><?php echo e(__('represent')); ?></th>
        <th class="text-center"><?php echo e(__('phone')); ?></th>
        <th class="text-center"><?php echo e(__('action')); ?></th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="p-0 border text-center align-middle"><?php echo e($item['shop_code']); ?></td>
            <td class="p-0 border text-left align-middle px-1"><?php echo e($item['shop_name']); ?></td>
            <td class="p-0 border text-left align-middle px-1 text-ellipsis"><?php echo e($item['address_1'] . $item['address_2']); ?></td>
            <td class="p-0 border text-left align-middle px-1"><?php echo e($item['phone']); ?></td>
            <td class="p-0 border text-left align-middle px-1"><?php echo e($item['user']['email']); ?></td>
            <td class="p-0 border text-left align-middle px-1"><?php echo e($item['represent']); ?></td>
            <td class="p-0 border text-left align-middle px-1"><?php echo e($item['represent_phone']); ?></td>
            <td class="p-0 border text-center align-middle">
                <input type="hidden" value="<?php echo e($item['shop_name']); ?>" class="shop_name">
                <input type="hidden" value="<?php echo e($item['post_code']); ?>" class="post_code">
                <input type="hidden" value="<?php echo e($item['address_1']); ?>" class="address_1">
                <input type="hidden" value="<?php echo e($item['address_2']); ?>" class="address_2">
                <input type="hidden" value="<?php echo e($item['phone']); ?>" class="phone">
                <input type="hidden" value="<?php echo e($item['user']['email']); ?>" class="email">
                <input type="hidden" value="<?php echo e($item['represent']); ?>" class="represent">
                <input type="hidden" value="<?php echo e($item['represent_phone']); ?>" class="represent_phone">
                <input type="hidden" value="<?php echo e($item['note']); ?>" class="note">
                <button class="btn btn-outline-dark waves-effect ex_change edit-shop" style="padding: 8px; margin: 5px;"
                        data-id="<?php echo e($item['id']); ?>" data-code="<?php echo e($item['shop_code']); ?>"><?php echo e(__('edit')); ?></button>
                <button class="btn btn-outline-dark waves-effect ex_change delete-shop" style="padding: 8px; margin: 5px;" data-id="<?php echo e($item['id']); ?>"><?php echo e(__('delete')); ?></button>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH D:\WORKSPACE\WEB\Reservation\Manager\resources\views/shop-table.blade.php ENDPATH**/ ?>