<h2>【<?php echo e($details['shop_name']); ?>】 予約キャンセルのお知らせ</h2>
<p><?php echo e($details['last_name']. " " . $details['first_name']); ?>さま</p>
<br>
<p>予約をキャンセルしました。以下キャンセルした予約の詳細になります。</p>
<br>
<p>店舗：<?php echo e($details['shop_name']); ?></p>
<p>予約番号：<?php echo e($details['reservation_code']); ?></p>
<p>予約日時：<?php echo e($details['reservation_time']); ?></p>
<p>メニュー：<?php echo e($details['menu']); ?></p>
<p>料金：<?php echo e($details['price']); ?></p>
<br>
<p>■ご注意<br>
    ※本メールに返信されましても、店舗にメールは届きません。<br>
    店舗へのご質問やご要望などありましたら、ご予約を頂いた店舗へ直接お問い合わせ下さい。
</p>
<br>
<p><?php echo e($details['shop_name']); ?></p>
<p><?php echo e($details['shop_address']); ?></p>
<p>電話　<?php echo e($details['shop_phone']); ?></p>
<?php /**PATH D:\WORKSPACE\WEB\Reservation\Reservation\resources\views/mail/reservation-cancel-client.blade.php ENDPATH**/ ?>