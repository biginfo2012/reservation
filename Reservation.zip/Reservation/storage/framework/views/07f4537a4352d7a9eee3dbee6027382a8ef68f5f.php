<div id="complete_part" class="col-12 col-sm-12 col-md-8 col-lg-8 px-xl-0 mx-auto" style="display: none">
    <div class="row">
        <div class="col-12">
            <div id="main-title" class="text-center">
                <h2 class="color-blue" style="font-weight: bold"><?php echo e(__('cancel-complete')); ?></h2>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12 text-center">
            <p><?php echo e(__('cancel-sentence')); ?></p>
        </div>
    </div>
</div>
<?php /**PATH D:\WORKSPACE\WEB\Reservation\Reservation\resources\views/cancel-complete.blade.php ENDPATH**/ ?>