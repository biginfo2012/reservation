<h2>予約受付のお知らせ</h2>
<br>
<p>予約を受け付けました。</p>
<br>
<p>予約番号：<?php echo e($details['reservation_code']); ?></p>
<p>予約日時：<?php echo e($details['reservation_time']); ?></p>
<p>予約者名：<?php echo e($details['last_name'] . " " . $details['first_name']); ?></p>
<p>電話番号：<?php echo e($details['client_phone']); ?></p>
<p>メールアドレス：<?php echo e($details['client_email']); ?></p>
<p>メニュー：<?php echo e($details['menu']); ?></p>
<p>料金：<?php echo e($details['price']); ?></p>
<p>ご要望：<?php echo e($details['note']); ?></p>
<?php /**PATH D:\WORKSPACE\WEB\Reservation\Reservation\resources\views/mail/reservation-complete-shop.blade.php ENDPATH**/ ?>