<h2>予約キャンセルのお知らせ</h2>
<br>
<p>予約をキャンセルされました。以下キャンセルした予約の詳細です。</p>
<br>
<p>予約番号：<?php echo e($details['reservation_code']); ?></p>
<p>予約日時：<?php echo e($details['reservation_time']); ?></p>
<p>予約者名：<?php echo e($details['last_name'] . " " . $details['first_name']); ?></p>
<p>電話番号：<?php echo e($details['client_phone']); ?></p>
<p>メールアドレス：<?php echo e($details['client_email']); ?></p>
<p>メニュー：<?php echo e($details['menu']); ?></p>
<p>料金：<?php echo e($details['price']); ?></p>
<?php /**PATH D:\WORKSPACE\WEB\Reservation\Reservation\resources\views/mail/reservation-cancel-shop.blade.php ENDPATH**/ ?>