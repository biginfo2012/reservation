<div id="time_part" class="col-12 col-sm-12 col-md-8 col-lg-8 px-xl-0 mx-auto" style="display: none">
    <div class="row">
        <div class="col-12 text-center">
            <div id="step">
                <div class="step-inner">
                    <span class="maru">1</span>
                    <span class="stext"><?php echo e(__('menu-select')); ?></span>
                </div><!-- step-inner -->
                <div class="step-inner">
                    <span class="maruon">2</span>
                    <span class="stext"><?php echo e(__('time-select')); ?></span>
                </div><!-- step-inner -->
                <div class="step-inner">
                    <span class="maru">3</span>
                    <span class="stext"><?php echo e(__('input-info')); ?></span>
                </div><!-- step-inner -->
                <div class="step-inner">
                    <span class="maru">4</span>
                    <span class="stext"><?php echo e(__('confirm-info')); ?></span>
                </div><!-- step-inner -->
                <div class="step-inner">
                    <span class="maru">5</span>
                    <span class="stext"><?php echo e(__('complete-info')); ?></span>
                </div><!-- step-inner -->
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div id="main-title" class="text-center">
                <h2 class="color-blue" style="font-weight: bold"><?php echo e(__('select-time')); ?></h2>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div id="content">
                <div class="coment">
                    <p id="time_alert" class="alert" style="display: none"><?php echo e(__('no-enough-time')); ?></p>
                </div>
                <div id="check" class="mb-1">
                    <table class="tacheck">
                        <tbody>
                        <tr>
                            <th><?php echo e(__('menu')); ?></th>
                            <td id="selected_menu"></td>
                        </tr>
                        <tr>
                            <th><?php echo e(__('selected-time')); ?></th>
                            <td id="selected_time"></td>
                        </tr>
                        <tr>
                            <th><?php echo e(__('selected-price')); ?></th>
                            <td><span id="selected_price"></span><br><span
                                    class="caution"><?php echo e(__('price-caution')); ?></span>
                            </td>
                        </tr>
                        </tbody>
                    </table><!-- tacheck -->
                </div><!-- check -->
                <input type="hidden" id="reservation_unit" value="<?php echo e($data['reservation_unit']); ?>">

                <div id="first_week_part">
                    <div id="time-btn">
                        <a id="next_week_btn" class="right-btn no2click"><?php echo e(__('next-week')); ?></a>
                    </div><!-- time-btn -->

                    <div class="component">
                        <div class="sticky-wrap">
                            <table class="sticky-enabled" style="margin: 0px;">
                                <thead>
                                <tr>
                                    <th rowspan="2" style="width:10% !important;"><?php echo e(__('day-time')); ?></th>
                                    <th colspan="<?php echo e($data['first_week_divide_span']); ?>"><?php echo e($data['first_week_month']); ?></th>
                                    <?php if($data['first_week_divide']): ?>
                                        <th colspan="<?php echo e(7 - $data['first_week_divide_span']); ?>"><?php echo e($data['first_week_divide_month']); ?></th>
                                    <?php endif; ?>
                                </tr>
                                <tr>
                                    <?php for($i = 0; $i < 7; $i++): ?>
                                        <th style="width: 12%"
                                            class="<?php echo e($data['weekdays'][$i] == "土" ? 'sat' : ($data['weekdays'][$i] == "日" ? 'sun' : "")); ?>"><?php echo e($data['first_week_days'][$i]); ?>

                                            <br>（<?php echo e($data['weekdays'][$i]); ?>）
                                        </th>
                                    <?php endfor; ?>
                                </tr>
                                </thead>
                                <tbody>
                                <?php for($i = 0,$iMax = count($data['time_array']); $i < $iMax; $i++): ?>
                                    <tr>
                                        <td class="time"><?php echo e($data['time_array'][$i]); ?></td>
                                        <?php for($j = 0; $j < 7; $j++): ?>
                                            <td>
                                                <a href="javascript:void(0);" data-week="<?php echo e($j); ?>" data-date="<?php echo e($data['first_week_days'][$j]); ?>" data-weekday="<?php echo e($data['weekdays'][$j]); ?>" data-time="<?php echo e($data['time_array'][$i]); ?>"
                                                   data-month="<?php echo e($data['first_week_divide'] ? ($j + 1 > $data['first_week_divide_span'] ? $data['first_week_divide_month'] : $data['first_week_month']) : $data['first_week_month']); ?>"
                                                   class="<?php echo e($data['first_week_arr'][$i][$j] ? 'reserveDate maru' : 'off'); ?>"><?php echo e($data['first_week_arr'][$i][$j] ? '◎' : '×'); ?></a>
                                            </td>
                                        <?php endfor; ?>
                                    </tr>
                                <?php endfor; ?>
                                </tbody>
                            </table>
                        </div>
                    </div><!-- component -->
                </div><!-- time -->
                <div id="second_week_part" style="display: none">
                    <div id="time-btn">
                        <a id="prev_week_btn" class="left-btn no2click"><?php echo e(__('prev-week')); ?></a>
                    </div><!-- time-btn -->

                    <div class="component">
                        <div class="sticky-wrap">
                            <table class="sticky-enabled" style="margin: 0px;">
                                <thead>
                                <tr>
                                    <th rowspan="2" style="width:10% !important;"><?php echo e(__('day-time')); ?></th>
                                    <th colspan="<?php echo e($data['second_week_divide_span']); ?>"><?php echo e($data['second_week_month']); ?></th>
                                    <?php if($data['second_week_divide']): ?>
                                        <th colspan="<?php echo e(7 - $data['second_week_divide_span']); ?>"><?php echo e($data['second_week_divide_month']); ?></th>
                                    <?php endif; ?>
                                </tr>
                                <tr>
                                    <?php for($i = 0; $i < 7; $i++): ?>
                                        <th style="width: 12%"
                                            class="<?php echo e($data['weekdays'][$i] == "土" ? 'sat' : ($data['weekdays'][$i] == "日" ? 'sun' : "")); ?>"><?php echo e($data['second_week_days'][$i]); ?>

                                            <br>（<?php echo e($data['weekdays'][$i]); ?>）
                                        </th>
                                    <?php endfor; ?>
                                </tr>
                                </thead>
                                <tbody>
                                <?php for($i = 0,$iMax = count($data['time_array']); $i < $iMax; $i++): ?>
                                    <tr>
                                        <td class="time"><?php echo e($data['time_array'][$i]); ?></td>
                                        <?php for($j = 0; $j < 7; $j++): ?>
                                            <td>
                                                <a href="javascript:void(0);" data-week="<?php echo e($j); ?>" data-date="<?php echo e($data['second_week_days'][$j]); ?>" data-weekday="<?php echo e($data['weekdays'][$j]); ?>" data-time="<?php echo e($data['time_array'][$i]); ?>"
                                                   data-month="<?php echo e($data['second_week_divide'] ? ($j + 1 > $data['second_week_divide_span'] ? $data['second_week_divide_month'] : $data['second_week_month']) : $data['second_week_month']); ?>"
                                                   class="<?php echo e($data['second_week_arr'][$i][$j] ? 'reserveDate maru' : 'off'); ?>"><?php echo e($data['second_week_arr'][$i][$j] ? '◎' : '×'); ?></a>
                                            </td>
                                        <?php endfor; ?>
                                    </tr>
                                <?php endfor; ?>
                                </tbody>
                            </table>
                        </div>
                    </div><!-- component -->
                </div><!-- time -->

                <div id="content-footer">
                    <a id="back_menu" class="f-btn1"><?php echo e(__('back')); ?></a>
                </div><!-- content-footer -->
            </div>
        </div>
    </div>
</div>
<script>
    $('#back_menu').click(function () {
        $('#menu_part').show();
        $('#time_part').hide()
    })
    $('#next_week_btn').click(function () {
        $('#first_week_part').hide();
        $('#second_week_part').show();
    })
    $('#prev_week_btn').click(function () {
        $('#first_week_part').show();
        $('#second_week_part').hide();
    })
    $('a.reserveDate').click(function () {
        let reservation_unit = $('#reservation_unit').val()
        let time = $('#totalTime').attr('time') - reservation_unit
        let week = $(this).data('week')
        $t = $(this).parent().parent()
        let show_alert = false
        while(time > 0){
            let next = $t.next().find('a.reserveDate[data-week=' + week + ']')
            if(next.length){
                time = time - reservation_unit
                $t = $t.next()
            }
            else{
                $('#time_alert').show()
                show_alert = true
                break
            }
        }
        if(!show_alert){
            $('#time_alert').hide()
            $('#user_part').show()
            $('#time_part').hide()
            let selected_date = $(this).data('month') + $(this).data('date') + "(" +  $(this).data('weekday') + ") " + $(this).data('time')
            let reservation_time = $(this).data('month').replace("年", "-").replace("月", "-") + $(this).data('date').replace("日", "") + " " + $(this).data('time')
            console.log(reservation_time)
            $('#reservation_time').val(reservation_time)
            $('#visit_time').html(selected_date)
        }
    })
</script>
<?php /**PATH D:\WORKSPACE\WEB\Reservation\Reservation\resources\views/time.blade.php ENDPATH**/ ?>