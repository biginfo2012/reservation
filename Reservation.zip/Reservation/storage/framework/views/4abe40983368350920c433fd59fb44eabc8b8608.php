<div id="cancel_part" class="col-12 col-sm-12 col-md-8 col-lg-8 px-xl-0 mx-auto">
    <div class="row">
        <div class="col-12">
            <div id="main-title" class="text-center">
                <h2 class="color-blue" style="font-weight: bold"><?php echo e(__('cancel-reservation')); ?></h2>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div id="content">
                <div id="check">
                    <p class="mb-0"><?php echo e(__('reservation-content')); ?></p>
                    <table class="tacheck">
                        <tbody>
                        <tr>
                            <th width="30%"><?php echo e(__('reservation-number')); ?></th>
                            <td id=""><?php echo e($reservation['reservation_code']); ?></td>
                        </tr>
                        <tr>
                            <th width="30%"><?php echo e(__('menu')); ?></th>
                            <td id="menu_confirm"><?php echo e($data['menus']); ?></td>
                        </tr>
                        <tr>
                            <th><?php echo e(__('selected-time')); ?></th>
                            <td id="menu_time"><?php echo e($data['time']); ?><?php echo e(__('min')); ?></td>
                        </tr>
                        <tr>
                            <th><?php echo e(__('selected-price')); ?></th>
                            <td><span id="menu_price"><?php echo e($data['price']); ?></span><br><span class="caution"><?php echo e(__('price-caution')); ?></span>
                            </td>
                        </tr>
                        <tr>
                            <th><?php echo e(__('visit-time')); ?></th>
                            <td id="visit_time"><?php echo e($data['visit']); ?></td>
                        </tr>
                        </tbody>
                    </table><!-- tacheck -->
                    <p class="mb-0 mt-1"><?php echo e(__('client-info')); ?></p>
                    <table class="tacheck">
                        <tbody>
                        <tr>
                            <th width="30%"><?php echo e(__('name')); ?></th>
                            <td id="confirm_name"><?php echo e($client->last_name . $client->first_name); ?></td>
                        </tr>
                        <tr>
                            <th><?php echo e(__('name-kana')); ?></th>
                            <td id="confirm_name_kana"><?php echo e($client->sei . $client->mei); ?></td>
                        </tr>
                        <!-- 質問 start -->
                        <!-- 質問 end -->
                        <tr>
                            <th><?php echo e(__('request')); ?></th>
                            <td id="confirm_request"><?php echo e($reservation->note); ?></td>
                        </tr>
                        </tbody>
                    </table><!-- tacheck -->
                </div><!-- check -->
                <input type="hidden" id="formReferer" name="referer" value="4">
                <div id="content-footer">
                    <form id="cancelForm" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="reservation_id" value="<?php echo e($reservation->id); ?>">
                    </form>
                    <a id="cancelReservation" href="javascript:void(0);"
                       class="f-btn disp-indicator"><?php echo e(__('reservation-cancel')); ?></a>
                    <a id="changeReservation" href="<?php echo e(route('reservation', $shop->shop_code)); ?>?delete_id=<?php echo e($reservation->id); ?>" class="f-btn" style="float:left;"><?php echo e(__('change-reservation')); ?></a>
                </div><!-- content-footer -->
                <div id="spinner_border" class="spinner-border" role="status" style="width: 3rem; height: 3rem; position: absolute; left: calc(50% - 1.5rem); top: 60%; display: none">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $('#cancelReservation').click(function () {
        let paramObj = new FormData($('#cancelForm')[0])
        $('#spinner_border').show()
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': token
            }
        })
        $.ajax({
            url: '<?php echo e(route('cancel-reservation-mail')); ?>',
            type: 'post',
            data: paramObj,
            contentType: false,
            processData: false,
            success: function (response) {
                $('#spinner_border').hide()
                if (response.status == true) {
                    toastr.success("成功しました。")
                    $('#cancel_part').hide()
                    $('#complete_part').show()
                } else {
                    toastr.warning("失敗しました。")
                }
            },
        })
    })
    $('#changeReservation').click(function () {
        let paramObj = new FormData($('#cancelForm')[0])
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': token
            }
        })
        $.ajax({
            url: '<?php echo e(route('cancel-reservation')); ?>',
            type: 'post',
            data: paramObj,
            contentType: false,
            processData: false,
            success: function (response) {
                if (response.status == true) {
                    window.location.href = '<?php echo e(route('reservation', $shop->shop_code)); ?>?delete_id=<?php echo e($reservation->id); ?>'
                } else {
                    toastr.warning("失敗しました。")
                }
            },
        })
    })
</script>

<?php /**PATH D:\WORKSPACE\WEB\Reservation\Reservation\resources\views/cancel.blade.php ENDPATH**/ ?>