<nav
    class="header-navbar navbar navbar-expand-lg align-items-center  navbar-light navbar-shadow container-xxl custom-header background-dark-blue color-white" style="position: absolute !important;">
    <?php if(!empty($shop_setting) && !empty($shop_setting->image_url)): ?>
        <img src="<?php echo e(asset('image') . '/' . $shop_setting->image_url); ?>" class="position-absolute" style="width: 100%; height: 250px;">
    <?php endif; ?>
    <div class="navbar-container d-flex content pb-0">
        <div class="bookmark-wrapper align-items-end col-12 col-sm-12 col-md-8 col-lg-8 px-xl-0 mx-auto mb-0 mt-auto">
            <p class="color-white font-medium-4 mb-0"><?php echo e(__('manager-sub-title')); ?></p>
            <p class="color-white mb-0"><?php echo e($shop->address); ?> <?php echo e($shop->shop_name); ?></p>
            <p class="color-white mb-0"><?php echo e($shop->phone); ?></p>
        </div>
    </div>
</nav>
<?php /**PATH D:\WORKSPACE\WEB\Reservation\Reservation\resources\views/header.blade.php ENDPATH**/ ?>