<footer class="footer footer-static footer-light footer-gradient color-white">
    <p class="clearfix mb-0 d-flex"><a href="https://makidumespecialty.shop/" target="_blank" class="float-md-start d-block d-md-inline-block mt-25 color-white" style="margin-left: auto; margin-right: 0;">{{__('policy')}}</a>　｜　<a href="https://makidumespecialty.shop/" target="_blank" class="float-md-start d-block d-md-inline-block mt-25 color-white" style="margin-right: auto; margin-left: 0;">{{__('privacy')}}</a></p>
    <p class="clearfix mb-0 d-flex"><a href="https://makidumespecialty.shop/" target="_blank" class="float-md-start d-block d-md-inline-block mt-25 color-white" style="margin: auto;">{{__('footer-title')}}</a></p>
    <p class="clearfix mb-0 d-flex text-center"><span class="float-md-start d-block d-md-inline-block mt-25 color-white" style="margin: auto">Copyright &copy; 2023 巻き爪専門センター, All rights Reserved</span></p>
</footer>
<button class="btn btn-primary btn-icon scroll-top" type="button"><i data-feather="arrow-up"></i></button>
