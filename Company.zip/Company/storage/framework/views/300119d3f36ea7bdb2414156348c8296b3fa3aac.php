<table class="table table-separate table-head-custom table-checkable" id="table">
    <thead>
    <tr>
        <th class="text-center">ID</th>
        <th class="text-center" colspan="2"><?php echo e(__('order-change')); ?></th>
        <th class="text-center"><?php echo e(__('menu-name')); ?></th>
        <th class="text-center"><?php echo e(__('description')); ?></th>
        <th class="text-center"><?php echo e(__('price')); ?></th>
        <th class="text-center"><?php echo e(__('require-time')); ?></th>
        <th class="text-center"><?php echo e(__('display')); ?></th>
        <th class="text-center"><?php echo e(__('action')); ?></th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="p-0 border text-center align-middle"><?php echo e($shop_code . '-' . $item['menu_code']); ?></td>
            <td class="p-0 border text-center align-middle px-1">
                <button type="button" class="btn btn-icon rounded-circle btn-warning btn_up" <?php echo e($index == 0 ? 'disabled' : ''); ?> data-id="<?php echo e($item['id']); ?>">
                    ▲
                </button>
            </td>
            <td class="p-0 border text-center align-middle px-1">
                <button type="button" class="btn btn-icon rounded-circle btn-warning btn_down" <?php echo e($index == count($data) - 1 ? 'disabled' : ''); ?> data-id="<?php echo e($item['id']); ?>">
                    ▼
                </button>
            </td>
            <td class="p-0 border text-left align-middle px-1"><?php echo e($item['menu_name']); ?></td>
            <td class="p-0 border text-left align-middle px-1"><?php echo e($item['description']); ?></td>
            <td class="p-0 border text-center align-middle"><?php echo e($item['ask'] == 1 ? __('ask') : ($item['over'] == 1 ? number_format($item['price']) . __('en-char') . __('over') : number_format($item['price']) . __('en-char'))); ?></td>
            <td class="p-0 border text-center align-middle"><?php echo e($item['require_time'] . __('min')); ?></td>
            <td class="p-0 border text-center align-middle">
                <div class="ms-1 d-flex text-center">
                    <div class="form-check me-1">
                        <input type="radio" name="display_table_<?php echo e($item['id']); ?>" class="form-check-input display_table" <?php echo e($item['display'] == 1 ? "checked" : ""); ?> value="1"/>
                        <label class="form-check-label publish-status"><?php echo e(__('on')); ?></label>
                    </div>
                    <div class="form-check">
                        <input type="radio" name="display_table_<?php echo e($item['id']); ?>" class="form-check-input display_table" <?php echo e($item['display'] == 0 ? "checked" : ""); ?> value="0"/>
                        <label class="form-check-label"><?php echo e(__('off')); ?></label>
                    </div>
                </div>
            </td>
            <td class="p-0 border text-center align-middle">
                <input type="hidden" value="<?php echo e($item['id']); ?>" class="id">
                <input type="hidden" value="<?php echo e($item['menu_name']); ?>" class="menu_name">
                <input type="hidden" value="<?php echo e($item['description']); ?>" class="description">
                <input type="hidden" value="<?php echo e($item['price']); ?>" class="price">
                <input type="hidden" value="<?php echo e($item['require_time']); ?>" class="require_time">
                <input type="hidden" value="<?php echo e($item['note']); ?>" class="note">
                <input type="hidden" value="<?php echo e($item['over']); ?>" class="over">
                <input type="hidden" value="<?php echo e($item['ask']); ?>" class="ask">
                <button class="btn btn-outline-dark waves-effect ex_change edit-menu" style="padding: 8px; margin: 5px;"
                        data-id="<?php echo e($item['id']); ?>" data-code="<?php echo e($item['menu_code']); ?>" data-display="<?php echo e($item['display']); ?>"><?php echo e(__('edit')); ?></button>
                <button class="btn btn-outline-dark waves-effect ex_change delete-menu" style="padding: 8px; margin: 5px;" data-id="<?php echo e($item['id']); ?>"><?php echo e(__('delete')); ?></button>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH D:\WORKSPACE\WEB\Reservation\Company\resources\views/menu-table.blade.php ENDPATH**/ ?>