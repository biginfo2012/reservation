<div class="main-menu menu-fixed menu-light menu-accordion menu-shadow background-dark-blue color-white" data-scroll-to-active="true">
    <div class="main-menu-content" style="margin-top: 6rem !important;">
        <ul class="navigation navigation-main background-dark-blue" id="main-menu-navigation" data-menu="menu-navigation">
            <li class="<?php echo e(str_contains(\Request::route()->getName(), 'dashboard') ? 'active' : ''); ?> nav-item">
                <a class="d-flex align-items-center" href="<?php echo e(route('dashboard')); ?>">
                    <span class="menu-title text-truncate" data-i18n="<?php echo e(__('dashboard')); ?>"><?php echo e(__('dashboard')); ?></span>
                </a>
            </li>
            <li class="<?php echo e(str_contains(\Request::route()->getName(), 'reservation') ? 'active' : ''); ?> nav-item">
                <a class="d-flex align-items-center" href="<?php echo e(route('reservation-list')); ?>">
                    <span class="menu-title text-truncate" data-i18n="<?php echo e(__('reservation-list')); ?>"><?php echo e(__('reservation-list')); ?></span>
                </a>
            </li>
            <li class="<?php echo e(str_contains(\Request::route()->getName(), 'client') ? 'active' : ''); ?> nav-item">
                <a class="d-flex align-items-center" href="<?php echo e(route('client-manage')); ?>">
                    <span class="menu-title text-truncate" data-i18n="<?php echo e(__('client-manage')); ?>"><?php echo e(__('client-manage')); ?></span>
                </a>
            </li>
            <li class="<?php echo e(str_contains(\Request::route()->getName(), 'noti') ? 'active' : ''); ?> nav-item">
                <a class="d-flex align-items-center" href="<?php echo e(route('noti-manage')); ?>">
                    <span class="menu-title text-truncate" data-i18n="<?php echo e(__('noti-manage')); ?>"><?php echo e(__('noti-manage')); ?></span>
                </a>
            </li>
            <li class="<?php echo e(str_contains(\Request::route()->getName(), 'shop') ? 'active' : ''); ?> nav-item">
                <a class="d-flex align-items-center" href="<?php echo e(route('shop-setting')); ?>">
                    <span class="menu-title text-truncate" data-i18n="<?php echo e(__('shop-setting')); ?>"><?php echo e(__('shop-setting')); ?></span>
                </a>
            </li>
            <li class="<?php echo e(str_contains(\Request::route()->getName(), 'menu') ? 'active' : ''); ?> nav-item">
                <a class="d-flex align-items-center" href="<?php echo e(route('menu-manage')); ?>">
                    <span class="menu-title text-truncate" data-i18n="<?php echo e(__('menu-manage')); ?>"><?php echo e(__('menu-manage')); ?></span>
                </a>
            </li>
            <li class="<?php echo e(str_contains(\Request::route()->getName(), 'my-page') ? 'active' : ''); ?> nav-item">
                <a class="d-flex align-items-center" href="<?php echo e(route('my-page')); ?>">
                    <span class="menu-title text-truncate" data-i18n="<?php echo e(__('my-page')); ?>"><?php echo e(__('my-page')); ?></span>
                </a>
            </li>
        </ul>
        <div style="position: absolute; bottom: 30px; left: 54px;">
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <a class="dropdown-item" onclick="event.preventDefault();
                                        this.closest('form').submit();">
                    <i class="me-50" data-feather="power"></i> <?php echo e(__('logout')); ?></a>
            </form>
        </div>

    </div>
</div>
<?php /**PATH D:\WORKSPACE\WEB\Reservation\Company\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>